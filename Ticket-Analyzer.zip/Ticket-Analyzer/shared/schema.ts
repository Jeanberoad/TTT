import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const configurations = pgTable("configurations", {
  id: serial("id").primaryKey(),
  wifiName: text("wifi_name").notNull().default("WiFi De Tsararano"),
  subtitle: text("subtitle").notNull().default("Connexion Internet"),
  supportText: text("support_text").notNull().default("Facebook: WiFi De Tsararano"),
  footerText: text("footer_text").notNull().default("à votre service 24h/24"),
  ticketsPerPage: integer("tickets_per_page").notNull().default(12),
  baseHost: text("base_host").notNull().default("https://hfj095c0e8a.sn.mynetname.net"),
  // Styles
  primaryColor: text("primary_color").notNull().default("#0ea5e9"),
  textColor: text("text_color").notNull().default("#0f172a"),
  backgroundColor: text("background_color").notNull().default("#ffffff"),
  borderRadius: integer("border_radius").notNull().default(16),
  borderWidth: integer("border_width").notNull().default(2),
  fontSize: integer("font_size").notNull().default(14),
});

export const insertConfigurationSchema = createInsertSchema(configurations).omit({ id: true });

export type Configuration = typeof configurations.$inferSelect;
export type InsertConfiguration = z.infer<typeof insertConfigurationSchema>;
export type UpdateConfigurationRequest = Partial<InsertConfiguration>;
