# Ticket Analyzer

## Overview
A full-stack web application for analyzing and displaying WiFi hotspot tickets. Built with React (Vite) frontend and Express backend, served from a single port (5000).

## Architecture

- **Frontend**: React 18 + TypeScript + Vite + Tailwind CSS (shadcn/ui components)
- **Backend**: Express 5 (Node.js) with TypeScript via `tsx`
- **Database**: PostgreSQL (Drizzle ORM)
- **Routing**: `wouter` on the client, Express on the server
- **State Management**: TanStack Query (react-query)

## Project Structure

```
/
├── client/           # React frontend (Vite root)
│   ├── index.html
│   └── src/
│       ├── App.tsx
│       ├── main.tsx
│       └── index.css
├── server/           # Express backend
│   ├── index.ts      # Entry point, listens on port 5000
│   ├── routes.ts     # API route handlers
│   ├── storage.ts    # Database access layer
│   ├── db.ts         # Drizzle/PostgreSQL connection
│   ├── vite.ts       # Vite dev middleware integration
│   └── static.ts     # Static file serving (production)
├── shared/           # Shared types/schema between front & back
│   ├── schema.ts     # Drizzle schema (configurations table)
│   └── routes.ts     # API route definitions with Zod validation
├── script/
│   └── build.ts      # Production build script
├── drizzle.config.ts # Drizzle Kit config
├── vite.config.ts    # Vite config (root: client/)
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

## Running the App

- **Development**: `npm run dev` — starts Express + Vite dev middleware on port 5000
- **Build**: `npm run build` — bundles frontend + compiles backend to `dist/`
- **Production**: `node dist/index.cjs`
- **DB push**: `npm run db:push`

## Key Configuration

- App listens on `0.0.0.0:5000` (required for Replit)
- `PORT` env variable defaults to 5000
- `DATABASE_URL` must be set (PostgreSQL connection string)
- Vite runs in middleware mode during development (no separate port)

## Database

- PostgreSQL via Replit's built-in database
- Single table: `configurations` — stores WiFi ticket display settings (colors, fonts, host URL, etc.)
- Auto-creates a default config row if none exists

## Deployment

- Target: autoscale
- Build: `npm run build`
- Run: `node dist/index.cjs`
