import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type ConfigInput } from "@shared/routes";

// Define a fallback in case DB is uninitialized initially
const defaultConfig = {
  id: 1,
  wifiName: "WiFi De Tsararano",
  subtitle: "Connexion Internet",
  supportText: "Facebook: WiFi De Tsararano",
  footerText: "à votre service 24h/24",
  ticketsPerPage: 12,
  baseHost: "https://hfj095c0e8a.sn.mynetname.net"
};

export function useConfig() {
  return useQuery({
    queryKey: [api.config.get.path],
    queryFn: async () => {
      const res = await fetch(api.config.get.path, { credentials: "include" });
      if (res.status === 404) return defaultConfig;
      if (!res.ok) throw new Error("Failed to fetch configuration");
      const data = await res.json();
      return api.config.get.responses[200].parse(data);
    },
  });
}

export function useUpdateConfig() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: ConfigInput) => {
      const validated = api.config.update.input.parse(data);
      const res = await fetch(api.config.update.path, {
        method: api.config.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.config.update.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to update configuration");
      }
      
      return api.config.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.config.get.path] });
    },
  });
}
