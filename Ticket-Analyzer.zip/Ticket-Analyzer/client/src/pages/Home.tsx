import { useState, useMemo } from "react";
import { TicketData } from "@/types/ticket";
import { useConfig } from "@/hooks/use-config";
import { CsvUploader } from "@/components/CsvUploader";
import { ConfigPanel } from "@/components/ConfigPanel";
import { TicketCard } from "@/components/TicketCard";
import { Printer, Filter, Trash2, LayoutGrid } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: config } = useConfig();
  const [tickets, setTickets] = useState<TicketData[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<string>("all");

  const profiles = useMemo(() => {
    const unique = new Set(tickets.map(t => t.profile).filter(Boolean));
    return Array.from(unique).sort();
  }, [tickets]);

  const filteredTickets = useMemo(() => {
    if (selectedProfile === "all") return tickets;
    return tickets.filter(t => t.profile === selectedProfile);
  }, [tickets, selectedProfile]);

  // Group tickets into pages based on config
  const pages = useMemo(() => {
    if (!config) return [];
    const perPage = config.ticketsPerPage || 12;
    const chunks = [];
    for (let i = 0; i < filteredTickets.length; i += perPage) {
      chunks.push(filteredTickets.slice(i, i + perPage));
    }
    return chunks;
  }, [filteredTickets, config]);

  const handlePrint = () => {
    window.print();
  };

  const handleClear = () => {
    if (window.confirm("Are you sure you want to clear all loaded tickets?")) {
      setTickets([]);
      setSelectedProfile("all");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Header - No Print */}
      <header className="glass-panel sticky top-0 z-40 px-6 py-4 flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <div className="bg-primary text-primary-foreground p-2 rounded-xl shadow-lg shadow-primary/20">
            <LayoutGrid className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl leading-tight">TicketGen</h1>
            <p className="text-xs text-muted-foreground font-medium">Hotspot Voucher Studio</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {tickets.length > 0 && (
            <>
              <button 
                onClick={handleClear}
                className="px-4 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 rounded-lg transition-colors flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Clear
              </button>
              
              <button 
                onClick={handlePrint}
                className="px-5 py-2 text-sm font-semibold bg-primary text-primary-foreground rounded-lg shadow-md shadow-primary/20 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                Print / PDF
              </button>
            </>
          )}
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 flex flex-col lg:flex-row gap-8 mt-4 items-start">
        {/* Left Sidebar: Controls - No Print */}
        <aside className="w-full lg:w-[380px] shrink-0 space-y-6 no-print sticky top-[100px]">
          <CsvUploader onUpload={setTickets} />
          
          {tickets.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-2xl border p-5 shadow-sm space-y-4"
            >
              <div className="flex items-center gap-2 font-display font-semibold text-lg text-foreground border-b pb-3">
                <Filter className="w-5 h-5 text-primary" />
                Filter & Stats
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Select Profile</label>
                <select 
                  value={selectedProfile}
                  onChange={(e) => setSelectedProfile(e.target.value)}
                  className="w-full px-3 py-2.5 bg-background border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-sm font-medium"
                >
                  <option value="all">All Profiles ({tickets.length})</option>
                  {profiles.map(p => (
                    <option key={p} value={p}>
                      {p} ({tickets.filter(t => t.profile === p).length})
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2 grid grid-cols-2 gap-3">
                <div className="bg-secondary/50 rounded-xl p-3 text-center border">
                  <div className="text-2xl font-display font-bold text-foreground">{filteredTickets.length}</div>
                  <div className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground mt-0.5">Tickets</div>
                </div>
                <div className="bg-secondary/50 rounded-xl p-3 text-center border">
                  <div className="text-2xl font-display font-bold text-foreground">{pages.length}</div>
                  <div className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground mt-0.5">Pages</div>
                </div>
              </div>
            </motion.div>
          )}

          <ConfigPanel />
        </aside>

        {/* Right Area: Preview and Print Pages */}
        <section className="flex-1 w-full min-w-0">
          {tickets.length === 0 ? (
            <div className="h-[400px] border-2 border-dashed rounded-3xl flex flex-col items-center justify-center text-muted-foreground/50 space-y-4 no-print bg-slate-50/50 dark:bg-slate-900/20">
              <LayoutGrid className="w-16 h-16 opacity-50" />
              <p className="text-lg font-medium">Upload a CSV to preview tickets</p>
            </div>
          ) : (
            <div className="space-y-12">
              {pages.map((pageTickets, pageIndex) => (
                <div 
                  key={pageIndex} 
                  className="ticket-page-break"
                >
                  {/* Page indicator (hidden on print) */}
                  <div className="mb-4 flex items-center gap-4 no-print">
                    <div className="h-px bg-border flex-1" />
                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest bg-secondary px-3 py-1 rounded-full">
                      Page {pageIndex + 1}
                    </span>
                    <div className="h-px bg-border flex-1" />
                  </div>

                  {/* Grid of tickets */}
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 print:grid-cols-3 print:gap-4">
                    {pageTickets.map((ticket, idx) => (
                      <TicketCard 
                        key={`${ticket.username}-${idx}`} 
                        ticket={ticket} 
                        config={config!} 
                        onUpdate={(updates) => {
                          const globalIdx = filteredTickets.indexOf(ticket);
                          if (globalIdx !== -1) {
                            const newTickets = [...tickets];
                            const ticketToUpdate = filteredTickets[globalIdx];
                            const originalIdx = tickets.indexOf(ticketToUpdate);
                            newTickets[originalIdx] = { ...ticketToUpdate, ...updates };
                            setTickets(newTickets);
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
