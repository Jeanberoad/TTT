import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import Papa from "papaparse";
import { UploadCloud, FileType, AlertCircle, CheckCircle2 } from "lucide-react";
import { TicketData } from "@/types/ticket";
import { motion, AnimatePresence } from "framer-motion";

interface CsvUploaderProps {
  onUpload: (tickets: TicketData[]) => void;
}

export function CsvUploader({ onUpload }: CsvUploaderProps) {
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    setIsSuccess(false);
    
    const file = acceptedFiles[0];
    if (!file) return;

    Papa.parse<TicketData>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim().toLowerCase(),
      complete: (results) => {
        if (results.errors.length > 0 && results.data.length === 0) {
          setError("Failed to parse CSV. Please ensure it's a valid file.");
          return;
        }

        // Validate basic required columns exist
        const sample = results.data[0];
        if (!sample || !('username' in sample)) {
          setError("CSV must contain at least a 'username' column.");
          return;
        }

        setIsSuccess(true);
        onUpload(results.data);
        
        // Reset success state after a delay
        setTimeout(() => setIsSuccess(false), 3000);
      },
      error: (err) => {
        setError(err.message);
      }
    });
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.csv']
    },
    maxFiles: 1,
  });

  return (
    <div className="w-full">
      <div
        {...getRootProps()}
        className={`
          relative overflow-hidden rounded-2xl border-2 border-dashed p-8 transition-all duration-300 ease-out cursor-pointer group
          ${isDragActive 
            ? 'border-primary bg-primary/5 shadow-inner' 
            : 'border-border hover:border-primary/50 hover:bg-slate-50 dark:hover:bg-slate-900/50'
          }
          ${error ? 'border-destructive/50 bg-destructive/5' : ''}
          ${isSuccess ? 'border-green-500/50 bg-green-500/5' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center justify-center text-center space-y-4">
          <div className={`p-4 rounded-full transition-colors duration-300 ${
            isDragActive ? 'bg-primary/20 text-primary' : 
            error ? 'bg-destructive/10 text-destructive' :
            isSuccess ? 'bg-green-500/10 text-green-500' :
            'bg-secondary text-muted-foreground group-hover:text-primary group-hover:bg-primary/10'
          }`}>
            {isSuccess ? <CheckCircle2 className="w-8 h-8" /> : 
             error ? <AlertCircle className="w-8 h-8" /> :
             <UploadCloud className="w-8 h-8" />}
          </div>
          
          <div className="space-y-1">
            <h3 className="font-display font-semibold text-lg text-foreground">
              {isDragActive ? "Drop CSV here..." : "Upload Tickets CSV"}
            </h3>
            <p className="text-sm text-muted-foreground max-w-xs mx-auto">
              Drag & drop your exported Hotspot tickets CSV here, or click to select a file.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground bg-background px-3 py-1.5 rounded-full border shadow-sm">
            <FileType className="w-3.5 h-3.5" />
            Requires: username, password, profile, limit_uptime
          </div>
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-3 text-sm text-destructive font-medium flex items-center justify-center gap-2"
          >
            <AlertCircle className="w-4 h-4" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
