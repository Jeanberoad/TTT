import { TicketData } from "@/types/ticket";
import { Wifi, Clock, User, KeyRound } from "lucide-react";

interface TicketCardProps {
  ticket: TicketData;
  config: {
    wifiName: string;
    subtitle: string;
    supportText: string;
    footerText: string;
    baseHost: string;
    primaryColor?: string;
    textColor?: string;
    backgroundColor?: string;
    borderRadius?: number;
    borderWidth?: number;
    fontSize?: number;
  };
  onUpdate?: (updates: Partial<TicketData>) => void;
}

export function TicketCard({ ticket, config, onUpdate }: TicketCardProps) {
  const qrUrlValue = ticket.qr_url?.trim() 
    ? ticket.qr_url.trim() 
    : `${config.baseHost}/login?username=${encodeURIComponent(ticket.username)}&password=${encodeURIComponent(ticket.password || "")}`;
  
  const qrImageSrc = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrUrlValue)}&format=svg`;

  const styles = {
    color: config.textColor,
    backgroundColor: config.backgroundColor,
    borderRadius: `${config.borderRadius}px`,
    borderWidth: `${config.borderWidth}px`,
    fontSize: `${config.fontSize}px`,
  };

  const handleEdit = (field: keyof TicketData, value: string) => {
    if (onUpdate) {
      onUpdate({ [field]: value });
    }
  };

  return (
    <div 
      style={styles}
      className="ticket-container ticket-card-content relative group border-2 ticket-border border-border/60 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-[240px]"
    >
      {/* Decorative top accent */}
      <div 
        className="absolute top-0 left-0 right-0 h-1.5" 
        style={{ backgroundColor: config.primaryColor }}
      />
      
      {/* Header */}
      <div className="px-4 py-3 flex items-center justify-between border-b ticket-border border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="p-1.5 rounded-lg shrink-0" style={{ backgroundColor: `${config.primaryColor}20` }}>
            <Wifi className="w-4 h-4" style={{ color: config.primaryColor }} />
          </div>
          <div className="flex flex-col truncate">
            <h3 
              contentEditable 
              suppressContentEditableWarning
              onBlur={(e) => handleEdit('username', e.currentTarget.textContent || ticket.username)}
              className="font-display font-bold text-sm leading-tight truncate outline-none focus:ring-1 ring-primary rounded px-1"
            >
              {config.wifiName}
            </h3>
            <span className="text-[10px] ticket-text-muted text-slate-500 truncate">
              {config.subtitle}
            </span>
          </div>
        </div>
        <div 
          className="text-white text-[10px] font-semibold px-2.5 py-1 rounded-full shrink-0"
          style={{ backgroundColor: config.primaryColor }}
        >
          {ticket.profile}
        </div>
      </div>

      {/* Content Body */}
      <div className="flex-1 p-4 flex gap-4">
        {/* Left Side: Credentials */}
        <div className="flex-1 flex flex-col justify-center space-y-3">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold ticket-text-muted text-slate-500">
              <User className="w-3 h-3" /> Nom d'utilisateur
            </div>
            <div 
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleEdit('username', e.currentTarget.textContent || ticket.username)}
              className="bg-slate-50 ticket-border border border-slate-200 rounded-lg px-3 py-1.5 font-mono font-bold text-lg tracking-wide select-all outline-none focus:ring-2 ring-primary/50"
            >
              {ticket.username}
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold ticket-text-muted text-slate-500">
              <KeyRound className="w-3 h-3" /> Mot de passe
            </div>
            <div 
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleEdit('password', e.currentTarget.textContent || ticket.password || "")}
              className="bg-slate-50 ticket-border border border-slate-200 rounded-lg px-3 py-1.5 font-mono font-bold text-lg tracking-wide select-all outline-none focus:ring-2 ring-primary/50"
            >
              {ticket.password}
            </div>
          </div>
        </div>

        {/* Right Side: QR Code & Duration */}
        <div className="shrink-0 flex flex-col items-center justify-center space-y-2">
          <div className="bg-white p-1.5 rounded-xl border ticket-border border-slate-200 shadow-sm">
            <img 
              src={qrImageSrc} 
              alt="Login QR Code" 
              className="w-[84px] h-[84px] object-contain"
              loading="lazy"
            />
          </div>
          <div 
            contentEditable
            suppressContentEditableWarning
            onBlur={(e) => handleEdit('limit_uptime', e.currentTarget.textContent || ticket.limit_uptime || "")}
            className="flex items-center gap-1 text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-1 rounded-md w-full justify-center outline-none focus:ring-1 ring-primary"
          >
            <Clock className="w-3 h-3" />
            {ticket.limit_uptime || "Illimité"}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-4 py-2 bg-slate-50 ticket-border border-t border-slate-100 flex items-center justify-between text-[9px] font-medium ticket-text-muted text-slate-500">
        <span className="truncate pr-2">{config.supportText}</span>
        <span className="truncate shrink-0">{config.footerText}</span>
      </div>
    </div>
  );
}
